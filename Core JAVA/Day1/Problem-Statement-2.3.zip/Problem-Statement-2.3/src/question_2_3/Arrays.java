package question_2_3;

public class Arrays {
	static int getMin(int arr[], int n)
    {
        int res = arr[0];
         
        for (int i = 1; i < n; i++)
            res = Math.min(res, arr[i]);
        return res;
    }
	public static void main(String[] args) {  
        
		int sum = 0;  
		
		
        int [] arr = new int [] {3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0};  
        
        for (int i = 0; i < arr.length; i++) {  
           sum = sum + arr[i];  
        }  
        
        System.out.println("Sum of elements from index 0 to 14 is: " + sum);  
        double average = sum / arr.length;
        System.out.println("The average of all number in the array is: " + average); 
        int n = arr.length;
        System.out.println( "The smallest element in the array is: " + getMin(arr, n));
   
	} 
}