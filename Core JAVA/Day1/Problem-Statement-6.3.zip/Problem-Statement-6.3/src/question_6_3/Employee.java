package question_6_3;

class EmployeeDetails {  
	int emp_id;  
	String name, address;  
  
	public int getEmp_id() {  
	  return emp_id;  
	}  
	public void setEmp_id(int emp_id) {  
	  this.emp_id = emp_id;  
	}  
	 
	public String getName() {  
	  return name;  
	}  
	public void setName(String name) {  
	  this.name = name;  
	}  
	public String getAddress() {  
	  return address;  
	}  
	public void setAddress(String address) {  
	  this.address = address;  
	}
	@Override
	public String toString() {
		return "EmployeeDetails [emp_id=" + emp_id + ", name=" + name + ", address=" + address + "]";
	}  

	    
	}  
	public class Employee{  
	  public static void main(String args[]) {  
	         
	      EmployeeDetails emp = new EmployeeDetails(); 
	      emp.setEmp_id(123);  
	      emp.setName("Ironman");  
	      emp.setAddress("London"); 
	      System.out.println(emp); 
	      emp.setEmp_id(456);  
	      emp.setName("Captain America");  
	      emp.setAddress("New York"); 
	      System.out.println(emp);  
	      emp.setEmp_id(789);  
	      emp.setName("Black Widow");  
	      emp.setAddress("Russia"); 
	      System.out.println(emp);   
	        
	  }  
	}  