package question_3_2;

public class MedicineInfo {
	public void displayLabel()
	{
		System.out.println("Company : Apollo Pharmacy");
		System.out.println("Address : Hyderabad");
	}
}
class Tablet extends MedicineInfo{
	 
	public void displayLabel()
	{
		System.out.println("Store in a cool dry place");
	}
}
class Syrup extends MedicineInfo{
	public void displayLabel()
	{
		System.out.println("Consumption as directed by the physician");
	}
}
class Ointment extends MedicineInfo{
	public void displayLabel()
	{
		System.out.println("For external use only");
	}
}