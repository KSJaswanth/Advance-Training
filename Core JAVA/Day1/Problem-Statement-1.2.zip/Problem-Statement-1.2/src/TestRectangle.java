import java.util.Scanner;

class TestRectangle {
    int length; 
    int breadth; 
    int area; 
   
    public TestRectangle()
    {
    	length = 0;
    	breadth= 0;
    }

    void input() {
        Scanner in = new Scanner(System.in);
        
        System.out.print("Enter length of rectangle: ");
        length = in.nextInt();
        System.out.print("Enter breadth of rectangle: ");
        breadth = in.nextInt();
    }

    void calculate() {
        area = length * breadth;
        
    }

    void display() {
    	
        System.out.println("Area of Rectangle is = " + area);
       
    }

    public static void main(String args[]) {
    	System.out.println("----Rectangle 1----");
    	TestRectangle obj1 = new TestRectangle();
        obj1.input();
        obj1.calculate();
        obj1.display();
        System.out.println("----Rectangle 2----");
        TestRectangle obj2 = new TestRectangle();
        obj2.input();
        obj2.calculate();
        obj2.display();
        System.out.println("----Rectangle 3----");
        TestRectangle obj3 = new TestRectangle();
        obj3.input();
        obj3.calculate();
        obj3.display();
        System.out.println("----Rectangle 4----");
        TestRectangle obj4 = new TestRectangle();
        obj4.input();
        obj4.calculate();
        obj4.display();
        System.out.println("----Rectangle 5----");
        TestRectangle obj5 = new TestRectangle();
        obj5.input();
        obj5.calculate();
        obj5.display();
    }
}