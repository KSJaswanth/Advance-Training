package question_3_1;

public class Guitar extends Instruments {

	@Override
	public void play() {
		System.out.println("Guitar is playing  tin  tin  tin");

	}

}