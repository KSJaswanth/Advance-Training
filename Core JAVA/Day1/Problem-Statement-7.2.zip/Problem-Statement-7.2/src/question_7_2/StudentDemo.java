package question_7_2;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class StudentDemo {

    public static void main(String args[])throws Exception
    {
         BufferedReader br=new BufferedReader(new InputStreamReader(System.in));

         System.out.print("Enter Roll Number: ");
         int roll = Integer.parseInt(br.readLine());
         System.out.print("\nEnter Name: ");
         String name = br.readLine();
         System.out.print("\nEnter Age: ");
         int age = Integer.parseInt(br.readLine());
         System.out.print("\nEnter Course: ");
         String course = br.readLine();
         Student s = new Student(roll,name,age,course);
         s.display();
    }
}